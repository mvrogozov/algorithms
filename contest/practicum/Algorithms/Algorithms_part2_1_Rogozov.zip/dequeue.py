# 68279198
class Dequeue:

    def __init__(self, max_size):
        self.queue = [None] * max_size
        self.head = 0
        self.tail = 0
        self.max_size = max_size
        self.size = 0

    def push_back(self, value):
        if self.size < self.max_size:
            self.queue[self.tail] = value
            self.tail = (self.tail + 1) % self.max_size
            self.size += 1
        else:
            print('error')

    def push_front(self, value):
        if self.size < self.max_size:
            self.head = (self.head - 1) % self.max_size
            self.queue[self.head] = value
            self.size += 1
        else:
            print('error')

    def pop_back(self):
        if self.size != 0:
            self.tail = (self.tail - 1) % self.max_size
            print(self.queue[self.tail])
            self.queue[self.tail] = None
            self.size -= 1
        else:
            print('error')

    def pop_front(self):
        if self.size != 0:
            print(self.queue[self.head])
            self.queue[self.head] = None
            self.head = (self.head + 1) % self.max_size
            self.size -= 1
        else:
            print('error')

    def show_queue(self):
        print(self.queue)


def main():

    command_amount = int(input())
    max_size = int(input())
    new_dequeue = Dequeue(max_size)
    for index in range(command_amount):
        readed_command = input().strip().split()
        if readed_command[0] == 'push_front':
            new_dequeue.push_front(readed_command[1])
        if readed_command[0] == 'push_back':
            new_dequeue.push_back(readed_command[1])
        if readed_command[0] == 'pop_front':
            new_dequeue.pop_front()
        if readed_command[0] == 'pop_back':
            new_dequeue.pop_back()


if __name__ == '__main__':
    main()
