# 68317767
class Stack:

    def __init__(self):
        self.items = []

    def push(self, item):
        self.items.append(item)

    def pop(self):
        if self.items:
            return self.items.pop()
        else:
            return None


def calculator(input_data):
    stack = Stack()
    signs = ('+', '-', '*', '/')
    result = 0
    for elem in input_data:
        if elem in signs:
            operand_1 = stack.pop()
            operand_2 = stack.pop()
            if elem == '+':
                result = operand_2 + operand_1
            elif elem == '-':
                result = operand_2 - operand_1
            elif elem == '*':
                result = operand_2 * operand_1
            elif elem == '/':
                result = operand_2 // operand_1
        else:
            result = int(elem)
        stack.push(result)
    print(result)


def main():
    input_data = input().split()
    calculator(input_data)


if __name__ == '__main__':
    main()
