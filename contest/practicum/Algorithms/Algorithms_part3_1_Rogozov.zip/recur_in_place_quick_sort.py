# 68687416
def is_better(first, second):
    if first[1] == second[1]:
        if first[2] == second[2]:
            return first[0] <= second[0]
        return first[2] < second[2]
    return first[1] > second[1]


def in_place_quick_sort(arr, left, right):
    if right - left < 1:
        return
    if right - left == 1:
        if is_better(arr[right], arr[left]):
            arr[left], arr[right] = arr[right], arr[left]
        return
    mid = left + (right - left) // 2
    pivot = arr[mid]
    left_index = left
    right_index = right
    while left_index < right_index:
        if is_better(arr[left_index], pivot):
            left_index += 1
        if is_better(pivot, arr[right_index]):
            right_index -= 1
        if left_index >= right_index:
            break
        if (
            is_better(pivot, arr[left_index])
            and is_better(arr[right_index], pivot)
        ):
            arr[left_index], arr[right_index] = (
                arr[right_index], arr[left_index]
            )
            left_index += 1
            right_index -= 1
    in_place_quick_sort(arr, left, left_index)
    in_place_quick_sort(arr, left_index, right)
    return


if __name__ == '__main__':
    n = int(input())
    arr = [None] * n
    for i in range(n):
        in_data = list(input().split())
        arr[i] = in_data
        arr[i][0] = in_data[0]
        arr[i][1] = int(in_data[1])
        arr[i][2] = int(in_data[2])
    in_place_quick_sort(arr, 0, n - 1)
    result = ''
    for elem in arr:
        result += elem[0] + '\n'
    print(result)
