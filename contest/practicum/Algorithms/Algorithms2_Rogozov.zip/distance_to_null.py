# 67911251
from typing import List, Tuple, Union


def get_distances_to_null(
    nums: Union[List[int], Tuple[int, ...]]
) -> List[int]:
    nums_length = len(nums)
    distances: List[int] = [0] * nums_length
    zeros = [index for index, value in enumerate(nums) if value == 0]

    for index in range(0, zeros[0]):
        distances[index] = zeros[0] - index

    for zeros_index in range(len(zeros) - 1):
        for index in range(zeros[zeros_index], zeros[zeros_index + 1]):
            to_left: int = index - zeros[zeros_index]
            to_right: int = zeros[zeros_index + 1] - index
            if to_left <= to_right:
                distances[index] = to_left
            else:
                distances[index] = to_right

    for index in range(zeros[-1], nums_length):
        distances[index] = index - zeros[-1]

    return distances


if __name__ == '__main__':
    input()
    print(*get_distances_to_null(list(map(int, input().split()))))
