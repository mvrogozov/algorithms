# 67912878
from typing import List, Tuple, Union


def max_score(hands: int, digit_field: Union[str, List, Tuple]) -> int:
    all_num: str = ''.join(map(str, digit_field))
    return sum(
        1 for digit in range(1, 10) if (
            0 < all_num.count(str(digit)) <= (hands * 2)
            )
        )


if __name__ == '__main__':
    print(max_score(int(input()), ''.join(input() for digit in range(4))))
