#67886296
from typing import List, Tuple, Dict


def read_input() -> Tuple[int, List[str]]:
    n: int = int(input())
    digits_list: List[str] = [input() for i in range(4)]
    return n, digits_list


def max_score(n: int, l: List[str]) -> int:
    dict_num: Dict = {}
    all_num: str = ''.join(l)
    score: int = 0
    for i in all_num:
        dict_num[i] = dict_num.get(i, 0) + 1
    for key, value in dict_num.items():
        if key != '.':
            if value <= n * 2:
                score += 1

    return score


if __name__ == '__main__':
    n, digits_list = read_input()
    print(max_score(n, digits_list))
