# 67918573
POSSIBLE_VALUES = [
    '1', '2', '3', '4', '5', '6', '7', '8', '9'
]


def max_score(
    hands: int,
    symbol_field,
    possible_values=POSSIBLE_VALUES,
    hands_amount=2
) -> int:
    return sum(
        0 < symbol_field.count(digit) <= (hands * hands_amount)
        for digit in possible_values
        )


if __name__ == '__main__':
    print(max_score(
        hands=int(input()),
        symbol_field=f'{input()}{input()}{input()}{input()}')
    )
